# HNH Photobooth

A modern, event-ready web photobooth application built with React, TypeScript, and Tailwind CSS.

## Features

- **Multi-Shot Capture**: Take 1-8 photos in a single session
- **12+ Frame Designs**: Choose from various styles (cute, elegant, fun, minimal, retro, modern)
- **Live Camera Preview**: Real-time video feed with face-centering guide
- **Countdown Timer**: 3-2-1 countdown with visual and audio cues
- **Auto Composition**: Photos are automatically arranged in the selected frame
- **Download & Share**: Save or share your composed photobooth image
- **Dark Mode**: Automatic theme switching based on system preference
- **Responsive Design**: Works on mobile, tablet, and desktop devices
- **Auto Reset**: Returns to welcome screen after 30 seconds of inactivity

## User Flow

1. **Welcome Screen**: Animated brand lockup with "Start" button
2. **Shot Selection**: Choose number of photos (1-8)
3. **Frame Selection**: Browse and select from 12+ frame designs
4. **Camera Capture**: Take photos with countdown and progress indicator
5. **Preview & Actions**: View composed image, download, share, or retake

## Technical Stack

- **React 18** with TypeScript
- **Framer Motion** for smooth animations
- **Tailwind CSS** for styling
- **shadcn/ui** components
- **HTML5 Canvas** for image composition
- **MediaDevices API** for camera access

## Camera Permissions

The app requires camera access to function. If denied, users will see instructions on how to enable it.

## Browser Compatibility

- Chrome/Edge 90+
- Firefox 88+
- Safari 14+
- Mobile browsers with camera support

## Development

The photobooth is structured as a modular component system:

- `PhotoboothContext`: Global state management
- `WelcomeScreen`: Entry point
- `ShotSelector`: Shot count selection
- `FrameGallery`: Frame design selection
- `CameraCapture`: Photo capture with countdown
- `PreviewScreen`: Final composition with actions

## Customization

### Adding New Frames

Edit `src/data/frames.ts` to add new frame designs:

```typescript
{
  id: 'your-frame-id',
  name: 'Your Frame Name',
  category: 'cute' | 'elegant' | 'fun' | 'minimal' | 'retro' | 'modern',
  thumbnail: 'https://...',
  layout: createGridLayout, // or createVerticalStripLayout
}
```

### Adjusting Colors

Edit `src/index.css` to modify the color scheme:

- Light mode: `--primary: 0 79% 70%` (coral pink)
- Dark mode: `--primary: 189 100% 50%` (electric cyan)

### Changing Fonts

The app uses three Google Fonts:
- **Outfit**: Display/headings
- **Manrope**: Body text
- **JetBrains Mono**: Countdown numbers

## Performance

- Frame SVGs are kept under 50KB each
- Images are composed client-side (no server required)
- Animations target 60fps on mid-range devices
- Memory is cleared after each session

## Accessibility

- All touch targets are minimum 48×48px
- Keyboard navigation supported
- Screen reader friendly
- High contrast mode compatible

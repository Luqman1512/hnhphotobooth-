import { FrameDesign, PhotoLayout } from '@/types/photobooth';

const createGridLayout = (count: number): PhotoLayout => {
  const cols = count <= 2 ? count : count <= 4 ? 2 : count <= 6 ? 3 : 4;
  const rows = Math.ceil(count / cols);
  const slotWidth = 80 / cols;
  const slotHeight = 80 / rows;
  
  const slots = Array.from({ length: count }, (_, i) => {
    const col = i % cols;
    const row = Math.floor(i / cols);
    return {
      x: 10 + col * slotWidth,
      y: 10 + row * slotHeight,
      width: slotWidth - 2,
      height: slotHeight - 2,
    };
  });

  return { slots, frameStyle: {} };
};

const createVerticalStripLayout = (count: number): PhotoLayout => {
  const slotHeight = 90 / count;
  const slots = Array.from({ length: count }, (_, i) => ({
    x: 25,
    y: 5 + i * slotHeight,
    width: 50,
    height: slotHeight - 1,
  }));

  return { slots, frameStyle: {} };
};

// Frame preview SVG components
export const framePreviewSVGs: Record<string, string> = {
  'cute-pastels': `<svg viewBox="0 0 200 260" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="pastelGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" style="stop-color:#FFB6C1"/>
        <stop offset="50%" style="stop-color:#E6E6FA"/>
        <stop offset="100%" style="stop-color:#FFB6C1"/>
      </linearGradient>
    </defs>
    <rect width="200" height="260" fill="url(#pastelGrad)" rx="12"/>
    <rect x="15" y="15" width="170" height="200" fill="#fff" rx="8" opacity="0.9"/>
    <circle cx="30" cy="240" r="8" fill="#FFD700" opacity="0.6"/>
    <circle cx="50" cy="245" r="5" fill="#FF69B4" opacity="0.6"/>
    <circle cx="170" cy="238" r="6" fill="#87CEEB" opacity="0.6"/>
    <path d="M160 245 L165 235 L170 245 L175 235 L180 245" stroke="#FFD700" fill="none" stroke-width="2"/>
    <text x="100" y="252" text-anchor="middle" font-size="8" fill="#666" font-family="sans-serif">HNH PHOTOBOOTH</text>
  </svg>`,
  'kawaii-doodles': `<svg viewBox="0 0 200 260" xmlns="http://www.w3.org/2000/svg">
    <rect width="200" height="260" fill="#FFF0F5" rx="12"/>
    <rect x="15" y="15" width="170" height="200" fill="#fff" rx="8"/>
    <circle cx="25" cy="235" r="12" fill="#FFB6C1"/>
    <circle cx="21" cy="232" r="2" fill="#333"/>
    <circle cx="29" cy="232" r="2" fill="#333"/>
    <path d="M22 238 Q25 241 28 238" stroke="#333" fill="none" stroke-width="1.5"/>
    <circle cx="175" cy="235" r="12" fill="#87CEEB"/>
    <circle cx="171" cy="232" r="2" fill="#333"/>
    <circle cx="179" cy="232" r="2" fill="#333"/>
    <path d="M172 238 Q175 241 178 238" stroke="#333" fill="none" stroke-width="1.5"/>
    <path d="M90 225 L95 235 L100 225 L105 235 L110 225" stroke="#FF69B4" fill="none" stroke-width="2"/>
    <circle cx="60" cy="240" r="4" fill="#FF69B4"/>
    <circle cx="140" cy="240" r="4" fill="#FF69B4"/>
    <text x="100" y="255" text-anchor="middle" font-size="8" fill="#666" font-family="sans-serif">HNH PHOTOBOOTH</text>
  </svg>`,
  'minimal-modern': `<svg viewBox="0 0 200 260" xmlns="http://www.w3.org/2000/svg">
    <rect width="200" height="260" fill="#FAFAFA" rx="4"/>
    <rect x="10" y="10" width="180" height="210" fill="#fff" stroke="#222" stroke-width="2" rx="2"/>
    <line x1="10" y1="230" x2="190" y2="230" stroke="#222" stroke-width="1"/>
    <text x="100" y="248" text-anchor="middle" font-size="10" fill="#222" font-family="Helvetica, sans-serif" font-weight="bold">HNH PHOTOBOOTH</text>
  </svg>`,
  'elegant-wedding': `<svg viewBox="0 0 200 260" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="goldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" style="stop-color:#D4AF37"/>
        <stop offset="50%" style="stop-color:#F5E6A3"/>
        <stop offset="100%" style="stop-color:#D4AF37"/>
      </linearGradient>
    </defs>
    <rect width="200" height="260" fill="#FFFEF5" rx="8"/>
    <rect x="12" y="12" width="176" height="206" fill="#fff" rx="4"/>
    <rect x="8" y="8" width="184" height="214" fill="none" stroke="url(#goldGrad)" stroke-width="3" rx="6"/>
    <path d="M20 230 Q30 220 40 230 Q50 240 60 230" stroke="#D4AF37" fill="none" stroke-width="1.5"/>
    <path d="M140 230 Q150 220 160 230 Q170 240 180 230" stroke="#D4AF37" fill="none" stroke-width="1.5"/>
    <circle cx="15" cy="15" r="8" fill="none" stroke="#D4AF37" stroke-width="1"/>
    <circle cx="185" cy="15" r="8" fill="none" stroke="#D4AF37" stroke-width="1"/>
    <circle cx="15" cy="215" r="8" fill="none" stroke="#D4AF37" stroke-width="1"/>
    <circle cx="185" cy="215" r="8" fill="none" stroke="#D4AF37" stroke-width="1"/>
    <text x="100" y="250" text-anchor="middle" font-size="9" fill="#D4AF37" font-family="serif" font-style="italic">HNH PHOTOBOOTH</text>
  </svg>`,
  'fun-party': `<svg viewBox="0 0 200 260" xmlns="http://www.w3.org/2000/svg">
    <rect width="200" height="260" fill="#FFF" rx="12"/>
    <rect x="15" y="15" width="170" height="200" fill="#fff" rx="8" stroke="#FF6B6B" stroke-width="3"/>
    <circle cx="25" cy="25" r="6" fill="#FF6B6B"/>
    <circle cx="45" cy="15" r="4" fill="#4ECDC4"/>
    <circle cx="175" cy="30" r="5" fill="#FFE66D"/>
    <circle cx="160" cy="12" r="3" fill="#FF6B6B"/>
    <rect x="30" cy="230" width="8" height="8" fill="#4ECDC4" transform="rotate(45 34 234)"/>
    <rect x="80" cy="225" width="6" height="6" fill="#FFE66D" transform="rotate(45 83 228)"/>
    <rect x="130" cy="232" width="7" height="7" fill="#FF6B6B" transform="rotate(45 133.5 235.5)"/>
    <rect x="170" cy="228" width="5" height="5" fill="#4ECDC4" transform="rotate(45 172.5 230.5)"/>
    <circle cx="55" cy="240" r="4" fill="#FFE66D"/>
    <circle cx="110" cy="238" r="3" fill="#4ECDC4"/>
    <circle cx="155" cy="242" r="4" fill="#FF6B6B"/>
    <text x="100" y="255" text-anchor="middle" font-size="9" fill="#FF6B6B" font-family="sans-serif" font-weight="bold">HNH PHOTOBOOTH</text>
  </svg>`,
  'retro-film': `<svg viewBox="0 0 200 260" xmlns="http://www.w3.org/2000/svg">
    <rect width="200" height="260" fill="#1a1a1a" rx="4"/>
    <rect x="25" y="10" width="150" height="210" fill="#2a2a2a"/>
    <rect x="30" y="15" width="140" height="200" fill="#f5f0e6"/>
    <rect x="5" y="20" width="12" height="8" fill="#1a1a1a" rx="2"/>
    <rect x="5" y="35" width="12" height="8" fill="#1a1a1a" rx="2"/>
    <rect x="5" y="50" width="12" height="8" fill="#1a1a1a" rx="2"/>
    <rect x="5" y="65" width="12" height="8" fill="#1a1a1a" rx="2"/>
    <rect x="5" y="80" width="12" height="8" fill="#1a1a1a" rx="2"/>
    <rect x="5" y="95" width="12" height="8" fill="#1a1a1a" rx="2"/>
    <rect x="5" y="110" width="12" height="8" fill="#1a1a1a" rx="2"/>
    <rect x="5" y="125" width="12" height="8" fill="#1a1a1a" rx="2"/>
    <rect x="5" y="140" width="12" height="8" fill="#1a1a1a" rx="2"/>
    <rect x="5" y="155" width="12" height="8" fill="#1a1a1a" rx="2"/>
    <rect x="5" y="170" width="12" height="8" fill="#1a1a1a" rx="2"/>
    <rect x="5" y="185" width="12" height="8" fill="#1a1a1a" rx="2"/>
    <rect x="5" y="200" width="12" height="8" fill="#1a1a1a" rx="2"/>
    <rect x="183" y="20" width="12" height="8" fill="#1a1a1a" rx="2"/>
    <rect x="183" y="35" width="12" height="8" fill="#1a1a1a" rx="2"/>
    <rect x="183" y="50" width="12" height="8" fill="#1a1a1a" rx="2"/>
    <rect x="183" y="65" width="12" height="8" fill="#1a1a1a" rx="2"/>
    <rect x="183" y="80" width="12" height="8" fill="#1a1a1a" rx="2"/>
    <rect x="183" y="95" width="12" height="8" fill="#1a1a1a" rx="2"/>
    <rect x="183" y="110" width="12" height="8" fill="#1a1a1a" rx="2"/>
    <rect x="183" y="125" width="12" height="8" fill="#1a1a1a" rx="2"/>
    <rect x="183" y="140" width="12" height="8" fill="#1a1a1a" rx="2"/>
    <rect x="183" y="155" width="12" height="8" fill="#1a1a1a" rx="2"/>
    <rect x="183" y="170" width="12" height="8" fill="#1a1a1a" rx="2"/>
    <rect x="183" y="185" width="12" height="8" fill="#1a1a1a" rx="2"/>
    <rect x="183" y="200" width="12" height="8" fill="#1a1a1a" rx="2"/>
    <text x="100" y="240" text-anchor="middle" font-size="8" fill="#f5f0e6" font-family="Courier, monospace">HNH PHOTOBOOTH</text>
    <text x="100" y="252" text-anchor="middle" font-size="7" fill="#888" font-family="Courier, monospace">2024</text>
  </svg>`,
  'neon-night': `<svg viewBox="0 0 200 260" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <filter id="glow">
        <feGaussianBlur stdDeviation="2" result="coloredBlur"/>
        <feMerge>
          <feMergeNode in="coloredBlur"/>
          <feMergeNode in="SourceGraphic"/>
        </feMerge>
      </filter>
    </defs>
    <rect width="200" height="260" fill="#0a0a1a" rx="12"/>
    <rect x="15" y="15" width="170" height="200" fill="#111" rx="8"/>
    <rect x="15" y="15" width="170" height="200" fill="none" stroke="#00D9FF" stroke-width="2" rx="8" filter="url(#glow)"/>
    <rect x="20" y="20" width="160" height="190" fill="none" stroke="#FF00FF" stroke-width="1" rx="6" opacity="0.5"/>
    <line x1="20" y1="230" x2="60" y2="230" stroke="#00D9FF" stroke-width="2" filter="url(#glow)"/>
    <line x1="140" y1="230" x2="180" y2="230" stroke="#FF00FF" stroke-width="2" filter="url(#glow)"/>
    <text x="100" y="250" text-anchor="middle" font-size="10" fill="#00D9FF" font-family="sans-serif" font-weight="bold" filter="url(#glow)">HNH PHOTOBOOTH</text>
  </svg>`,
  'floral-soft': `<svg viewBox="0 0 200 260" xmlns="http://www.w3.org/2000/svg">
    <rect width="200" height="260" fill="#F5F0E8" rx="12"/>
    <rect x="20" y="20" width="160" height="190" fill="#fff" rx="8"/>
    <path d="M15 225 Q25 215 35 225 Q45 235 55 225" stroke="#8FBC8F" fill="none" stroke-width="2"/>
    <circle cx="25" cy="220" r="4" fill="#DDA0DD" opacity="0.7"/>
    <circle cx="45" cy="230" r="3" fill="#FFB6C1" opacity="0.7"/>
    <path d="M145 225 Q155 215 165 225 Q175 235 185 225" stroke="#8FBC8F" fill="none" stroke-width="2"/>
    <circle cx="155" cy="220" r="4" fill="#DDA0DD" opacity="0.7"/>
    <circle cx="175" cy="230" r="3" fill="#FFB6C1" opacity="0.7"/>
    <ellipse cx="20" cy="30" rx="8" ry="12" fill="#8FBC8F" opacity="0.3"/>
    <ellipse cx="180" cy="30" rx="8" ry="12" fill="#8FBC8F" opacity="0.3"/>
    <text x="100" y="250" text-anchor="middle" font-size="9" fill="#8FBC8F" font-family="serif" font-style="italic">HNH PHOTOBOOTH</text>
  </svg>`,
  'clean-corporate': `<svg viewBox="0 0 200 260" xmlns="http://www.w3.org/2000/svg">
    <rect width="200" height="260" fill="#1E3A5F" rx="8"/>
    <rect x="15" y="15" width="170" height="200" fill="#fff" rx="4"/>
    <rect x="15" y="225" width="170" height="25" fill="#fff" rx="4"/>
    <line x1="25" y1="237" x2="55" y2="237" stroke="#1E3A5F" stroke-width="3"/>
    <text x="175" y="242" text-anchor="end" font-size="9" fill="#1E3A5F" font-family="Helvetica, sans-serif" font-weight="bold">HNH PHOTOBOOTH</text>
  </svg>`,
  'comic-pop': `<svg viewBox="0 0 200 260" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <pattern id="dots" patternUnits="userSpaceOnUse" width="8" height="8">
        <circle cx="4" cy="4" r="1.5" fill="#FF6B6B" opacity="0.3"/>
      </pattern>
    </defs>
    <rect width="200" height="260" fill="#FFF" rx="8"/>
    <rect width="200" height="260" fill="url(#dots)" rx="8"/>
    <rect x="15" y="15" width="170" height="200" fill="#fff" stroke="#222" stroke-width="4" rx="4"/>
    <path d="M20 230 L40 225 L35 240 L55 235 L50 250" stroke="#222" stroke-width="3" fill="#FFE66D"/>
    <path d="M150 225 L170 230 L165 245 L180 240" stroke="#222" stroke-width="3" fill="#FF6B6B"/>
    <ellipse cx="100" cy="240" rx="35" ry="12" fill="#fff" stroke="#222" stroke-width="2"/>
    <text x="100" y="244" text-anchor="middle" font-size="9" fill="#222" font-family="Impact, sans-serif">HNH PHOTOBOOTH</text>
  </svg>`,
  'gradient-aesthetic': `<svg viewBox="0 0 200 260" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="holoGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" style="stop-color:#9B59B6"/>
        <stop offset="33%" style="stop-color:#E74C3C"/>
        <stop offset="66%" style="stop-color:#F39C12"/>
        <stop offset="100%" style="stop-color:#FF6B9D"/>
      </linearGradient>
    </defs>
    <rect width="200" height="260" fill="url(#holoGrad)" rx="16"/>
    <rect x="15" y="15" width="170" height="200" fill="rgba(255,255,255,0.95)" rx="12"/>
    <rect x="20" y="225" width="160" height="25" fill="rgba(255,255,255,0.3)" rx="8"/>
    <text x="100" y="242" text-anchor="middle" font-size="10" fill="#fff" font-family="sans-serif" font-weight="bold">HNH PHOTOBOOTH</text>
  </svg>`,
  'dark-luxury': `<svg viewBox="0 0 200 260" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="roseGold" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" style="stop-color:#B76E79"/>
        <stop offset="50%" style="stop-color:#E8C4C4"/>
        <stop offset="100%" style="stop-color:#B76E79"/>
      </linearGradient>
    </defs>
    <rect width="200" height="260" fill="#1a1a1a" rx="12"/>
    <rect x="15" y="15" width="170" height="200" fill="#222" rx="8"/>
    <rect x="15" y="15" width="170" height="200" fill="none" stroke="url(#roseGold)" stroke-width="2" rx="8"/>
    <line x1="15" y1="15" x2="45" y2="45" stroke="url(#roseGold)" stroke-width="1"/>
    <line x1="185" y1="15" x2="155" y2="45" stroke="url(#roseGold)" stroke-width="1"/>
    <line x1="15" y1="215" x2="45" y2="185" stroke="url(#roseGold)" stroke-width="1"/>
    <line x1="185" y1="215" x2="155" y2="185" stroke="url(#roseGold)" stroke-width="1"/>
    <path d="M60 230 L80 230 M120 230 L140 230" stroke="url(#roseGold)" stroke-width="1"/>
    <text x="100" y="250" text-anchor="middle" font-size="9" fill="url(#roseGold)" font-family="serif" letter-spacing="2">HNH PHOTOBOOTH</text>
  </svg>`,
};

export const frameDesigns: FrameDesign[] = [
  {
    id: 'cute-pastels',
    name: 'Cute Pastels',
    category: 'cute',
    thumbnail: 'cute-pastels',
    layout: createGridLayout,
  },
  {
    id: 'kawaii-doodles',
    name: 'Kawaii Doodles',
    category: 'cute',
    thumbnail: 'kawaii-doodles',
    layout: createGridLayout,
  },
  {
    id: 'minimal-modern',
    name: 'Minimal Modern',
    category: 'minimal',
    thumbnail: 'minimal-modern',
    layout: createGridLayout,
  },
  {
    id: 'elegant-wedding',
    name: 'Elegant Wedding',
    category: 'elegant',
    thumbnail: 'elegant-wedding',
    layout: createGridLayout,
  },
  {
    id: 'fun-party',
    name: 'Fun Party',
    category: 'fun',
    thumbnail: 'fun-party',
    layout: createGridLayout,
  },
  {
    id: 'retro-film',
    name: 'Retro Film',
    category: 'retro',
    thumbnail: 'retro-film',
    layout: createVerticalStripLayout,
  },
  {
    id: 'neon-night',
    name: 'Neon Night',
    category: 'modern',
    thumbnail: 'neon-night',
    layout: createGridLayout,
  },
  {
    id: 'floral-soft',
    name: 'Floral Soft',
    category: 'elegant',
    thumbnail: 'floral-soft',
    layout: createGridLayout,
  },
];

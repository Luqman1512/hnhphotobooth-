import { motion } from 'framer-motion';
import { ArrowRight, ArrowLeft, Grid2X2, Grid3X3, LayoutGrid } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { usePhotobooth } from '@/contexts/PhotoboothContext';
import { cn } from '@/lib/utils';

const shotOptions = [1, 2, 3, 4, 5, 6, 7, 8];

const getLayoutIcon = (count: number) => {
  if (count <= 2) return <Grid2X2 className="w-4 h-4 sm:w-5 sm:h-5" />;
  if (count <= 4) return <Grid3X3 className="w-4 h-4 sm:w-5 sm:h-5" />;
  return <LayoutGrid className="w-4 h-4 sm:w-5 sm:h-5" />;
};

export function ShotSelector() {
  const { shotCount, setShotCount, setStep } = usePhotobooth();

  return (
    <div className="min-h-screen flex flex-col items-center justify-center noise-texture p-4 sm:p-6 md:p-8">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-6 sm:mb-8 md:mb-12"
      >
        <h2 className="font-display font-bold text-3xl sm:text-4xl md:text-5xl lg:text-6xl mb-2 sm:mb-4">
          How many shots?
        </h2>
        <p className="text-muted-foreground text-base sm:text-lg md:text-xl">
          Select the number of photos you'd like to take
        </p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.2 }}
        className="grid grid-cols-4 gap-2 sm:gap-3 md:gap-4 mb-6 sm:mb-8 md:mb-12 max-w-xs sm:max-w-md md:max-w-2xl w-full px-2"
      >
        {shotOptions.map((count, index) => (
          <motion.button
            key={count}
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.05 * index }}
            onClick={() => setShotCount(count)}
            className={cn(
              "aspect-square rounded-xl sm:rounded-2xl md:rounded-3xl font-display font-extrabold text-2xl sm:text-3xl md:text-4xl transition-all duration-200",
              "shadow-md hover:shadow-xl flex flex-col items-center justify-center gap-1",
              shotCount === count
                ? "bg-primary text-primary-foreground scale-105 shadow-xl ring-4 ring-primary/30"
                : "bg-card hover:bg-accent hover:scale-105 active:scale-95 border border-border"
            )}
          >
            <span>{count}</span>
            <span className={cn(
              "text-[10px] sm:text-xs font-normal",
              shotCount === count ? "text-primary-foreground/80" : "text-muted-foreground"
            )}>
              {count === 1 ? 'shot' : 'shots'}
            </span>
          </motion.button>
        ))}
      </motion.div>

      {/* Layout Preview */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
        className="mb-6 sm:mb-8 md:mb-12 p-4 sm:p-6 bg-card rounded-2xl border border-border shadow-lg"
      >
        <div className="flex items-center gap-3 text-muted-foreground">
          {getLayoutIcon(shotCount)}
          <span className="text-sm sm:text-base">
            Layout: {shotCount <= 2 ? 'Side by side' : shotCount <= 4 ? '2×2 Grid' : shotCount <= 6 ? '3×2 Grid' : 'Strip'}
          </span>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4 }}
        className="flex flex-col sm:flex-row gap-3 sm:gap-4 w-full sm:w-auto px-4 sm:px-0"
      >
        <Button
          variant="outline"
          size="lg"
          onClick={() => setStep('welcome')}
          className="px-6 sm:px-8 py-4 sm:py-6 text-base sm:text-lg rounded-full w-full sm:w-auto"
        >
          <ArrowLeft className="mr-2 h-4 w-4 sm:h-5 sm:w-5" />
          Back
        </Button>
        <Button
          size="lg"
          onClick={() => setStep('frame-select')}
          className="px-8 sm:px-12 py-4 sm:py-6 text-base sm:text-lg rounded-full font-display font-bold shadow-lg hover:shadow-xl w-full sm:w-auto"
        >
          Continue
          <ArrowRight className="ml-2 h-4 w-4 sm:h-5 sm:w-5" />
        </Button>
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.6 }}
        className="mt-6 sm:mt-8 md:mt-12 text-center"
      >
        <p className="text-muted-foreground text-sm sm:text-base">
          Selected: <span className="font-bold text-foreground text-xl sm:text-2xl">{shotCount}</span> {shotCount === 1 ? 'shot' : 'shots'}
        </p>
      </motion.div>
    </div>
  );
}

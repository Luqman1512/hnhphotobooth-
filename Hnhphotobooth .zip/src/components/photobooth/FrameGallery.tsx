import { motion } from 'framer-motion';
import { ArrowRight, ArrowLeft, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { usePhotobooth } from '@/contexts/PhotoboothContext';
import { frameDesigns, framePreviewSVGs } from '@/data/frames';
import { cn } from '@/lib/utils';

export function FrameGallery() {
  const { selectedFrame, setSelectedFrame, setStep, capturedPhotos, clearPhotos } = usePhotobooth();
  
  // Check if we have photos (coming from preview to change frame)
  const hasPhotos = capturedPhotos.length > 0;

  return (
    <div className="min-h-screen flex flex-col noise-texture p-4 sm:p-6 md:p-8">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-4 sm:mb-6 md:mb-8"
      >
        <h2 className="font-display font-bold text-3xl sm:text-4xl md:text-5xl lg:text-6xl mb-2 sm:mb-4">
          Choose Your Frame
        </h2>
        <p className="text-muted-foreground text-base sm:text-lg md:text-xl">
          Select a style that matches your vibe
        </p>
      </motion.div>

      <ScrollArea className="flex-1 mb-4 sm:mb-6 md:mb-8">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3 sm:gap-4 md:gap-6 pb-4 px-1"
        >
          {frameDesigns.map((frame, index) => (
            <motion.button
              key={frame.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.05 * index }}
              onClick={() => setSelectedFrame(frame)}
              className={cn(
                "relative rounded-xl sm:rounded-2xl overflow-hidden transition-all duration-200",
                "shadow-md hover:shadow-xl hover:-translate-y-1 bg-card",
                "border-2 border-transparent",
                selectedFrame?.id === frame.id && "ring-4 ring-primary scale-[1.02] shadow-xl border-primary"
              )}
            >
              <div className="aspect-[3/4] relative p-2 sm:p-3">
                <div 
                  className="w-full h-full"
                  dangerouslySetInnerHTML={{ __html: framePreviewSVGs[frame.thumbnail] || '' }}
                />
                {selectedFrame?.id === frame.id && (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="absolute top-2 right-2 sm:top-3 sm:right-3 bg-primary rounded-full p-1.5 sm:p-2"
                  >
                    <Check className="w-4 h-4 sm:w-5 sm:h-5 text-primary-foreground" />
                  </motion.div>
                )}
              </div>
              <div className="p-2 sm:p-3 bg-card border-t">
                <h3 className="font-display font-bold text-foreground text-sm sm:text-base mb-0.5">
                  {frame.name}
                </h3>
                <p className="text-muted-foreground text-xs sm:text-sm capitalize">
                  {frame.category}
                </p>
              </div>
            </motion.button>
          ))}
        </motion.div>
      </ScrollArea>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="flex flex-col sm:flex-row justify-center gap-3 sm:gap-4 px-4 sm:px-0"
      >
        <Button
          variant="outline"
          size="lg"
          onClick={() => {
            if (hasPhotos) {
              // Go back to preview if we have photos
              setStep('preview');
            } else {
              setStep('shot-select');
            }
          }}
          className="px-6 sm:px-8 py-4 sm:py-6 text-base sm:text-lg rounded-full w-full sm:w-auto"
        >
          <ArrowLeft className="mr-2 h-4 w-4 sm:h-5 sm:w-5" />
          Back
        </Button>
        <Button
          size="lg"
          onClick={() => {
            if (hasPhotos) {
              // Go back to preview with new frame
              setStep('preview');
            } else {
              // Start new capture
              setStep('camera');
            }
          }}
          disabled={!selectedFrame}
          className="px-8 sm:px-12 py-4 sm:py-6 text-base sm:text-lg rounded-full font-display font-bold shadow-lg hover:shadow-xl disabled:opacity-50 w-full sm:w-auto"
        >
          {hasPhotos ? 'Apply Frame' : 'Start Capture'}
          <ArrowRight className="ml-2 h-4 w-4 sm:h-5 sm:w-5" />
        </Button>
      </motion.div>
    </div>
  );
}

import { AnimatePresence, motion } from 'framer-motion';
import { usePhotobooth } from '@/contexts/PhotoboothContext';
import { WelcomeScreen } from './WelcomeScreen';
import { ShotSelector } from './ShotSelector';
import { FrameGallery } from './FrameGallery';
import { CameraCapture } from './CameraCapture';
import { PreviewScreen } from './PreviewScreen';

const pageVariants = {
  initial: { opacity: 0, x: 100 },
  animate: { opacity: 1, x: 0 },
  exit: { opacity: 0, x: -100 },
};

const pageTransition = {
  type: 'tween',
  ease: 'anticipate',
  duration: 0.4,
};

export function Photobooth() {
  const { step } = usePhotobooth();

  return (
    <div className="relative w-full h-full min-h-screen overflow-hidden">
      <AnimatePresence mode="wait">
        {step === 'welcome' && (
          <motion.div
            key="welcome"
            variants={pageVariants}
            initial="initial"
            animate="animate"
            exit="exit"
            transition={pageTransition}
            className="absolute inset-0"
          >
            <WelcomeScreen />
          </motion.div>
        )}

        {step === 'shot-select' && (
          <motion.div
            key="shot-select"
            variants={pageVariants}
            initial="initial"
            animate="animate"
            exit="exit"
            transition={pageTransition}
            className="absolute inset-0"
          >
            <ShotSelector />
          </motion.div>
        )}

        {step === 'frame-select' && (
          <motion.div
            key="frame-select"
            variants={pageVariants}
            initial="initial"
            animate="animate"
            exit="exit"
            transition={pageTransition}
            className="absolute inset-0"
          >
            <FrameGallery />
          </motion.div>
        )}

        {step === 'camera' && (
          <motion.div
            key="camera"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="absolute inset-0"
          >
            <CameraCapture />
          </motion.div>
        )}

        {step === 'preview' && (
          <motion.div
            key="preview"
            variants={pageVariants}
            initial="initial"
            animate="animate"
            exit="exit"
            transition={pageTransition}
            className="absolute inset-0"
          >
            <PreviewScreen />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

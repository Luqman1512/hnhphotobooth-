import { motion } from 'framer-motion';
import { Camera, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { usePhotobooth } from '@/contexts/PhotoboothContext';

export function WelcomeScreen() {
  const { setStep } = usePhotobooth();

  return (
    <div className="min-h-screen flex items-center justify-center noise-texture p-4 sm:p-6 md:p-8 relative overflow-hidden">
      {/* Decorative background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div
          animate={{ 
            rotate: 360,
            scale: [1, 1.1, 1],
          }}
          transition={{ 
            rotate: { duration: 20, repeat: Infinity, ease: "linear" },
            scale: { duration: 4, repeat: Infinity, ease: "easeInOut" }
          }}
          className="absolute -top-20 -right-20 w-40 h-40 sm:w-60 sm:h-60 md:w-80 md:h-80 bg-gradient-to-br from-primary/20 to-accent/20 rounded-full blur-3xl"
        />
        <motion.div
          animate={{ 
            rotate: -360,
            scale: [1, 1.2, 1],
          }}
          transition={{ 
            rotate: { duration: 25, repeat: Infinity, ease: "linear" },
            scale: { duration: 5, repeat: Infinity, ease: "easeInOut" }
          }}
          className="absolute -bottom-20 -left-20 w-40 h-40 sm:w-60 sm:h-60 md:w-80 md:h-80 bg-gradient-to-tr from-accent/20 to-primary/20 rounded-full blur-3xl"
        />
      </div>

      <div className="text-center relative z-10">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ 
            type: 'spring',
            stiffness: 200,
            damping: 20,
            duration: 0.6 
          }}
          className="mb-8 sm:mb-10 md:mb-12"
        >
          {/* Logo container with glow effect */}
          <motion.div 
            className="flex items-center justify-center mb-4 sm:mb-6 relative"
            animate={{ y: [0, -5, 0] }}
            transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
          >
            <div className="absolute inset-0 bg-primary/20 blur-2xl rounded-full scale-150" />
            <div className="relative bg-gradient-to-br from-primary to-accent p-4 sm:p-5 md:p-6 rounded-3xl shadow-2xl">
              <Camera className="w-12 h-12 sm:w-16 sm:h-16 md:w-20 md:h-20 text-primary-foreground" strokeWidth={1.5} />
            </div>
          </motion.div>
          
          <h1 className="font-display font-extrabold text-5xl sm:text-6xl md:text-7xl lg:text-8xl xl:text-9xl tracking-tight mb-2 sm:mb-4 bg-gradient-to-r from-foreground via-primary to-foreground bg-clip-text text-transparent bg-[length:200%_auto] animate-gradient">
            HNH
          </h1>
          <h2 className="font-display font-bold text-xl sm:text-2xl md:text-3xl lg:text-4xl xl:text-5xl tracking-[0.2em] sm:tracking-[0.3em] text-muted-foreground">
            PHOTOBOOTH
          </h2>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.4 }}
          className="relative"
        >
          <Button
            size="lg"
            onClick={() => setStep('shot-select')}
            className="text-lg sm:text-xl md:text-2xl px-10 sm:px-12 md:px-16 py-6 sm:py-7 md:py-8 rounded-full font-display font-bold shadow-2xl hover:shadow-primary/25 transition-all hover:scale-105 active:scale-95 relative overflow-hidden group"
          >
            <span className="relative z-10 flex items-center gap-2">
              <Sparkles className="w-5 h-5 sm:w-6 sm:h-6" />
              Start
              <Sparkles className="w-5 h-5 sm:w-6 sm:h-6" />
            </span>
            <motion.div
              className="absolute inset-0 bg-gradient-to-r from-primary via-accent to-primary bg-[length:200%_auto]"
              animate={{ backgroundPosition: ['0% center', '200% center'] }}
              transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
            />
          </Button>
        </motion.div>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6, duration: 0.4 }}
          className="mt-6 sm:mt-8 text-muted-foreground text-sm sm:text-base md:text-lg"
        >
          Tap to begin your photo session
        </motion.p>

        {/* Feature badges */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8, duration: 0.4 }}
          className="mt-8 sm:mt-10 md:mt-12 flex flex-wrap justify-center gap-2 sm:gap-3"
        >
          {['1-8 Shots', '12+ Frames', 'Instant Download'].map((feature, i) => (
            <span
              key={feature}
              className="px-3 sm:px-4 py-1.5 sm:py-2 bg-card/80 backdrop-blur-sm rounded-full text-xs sm:text-sm font-medium text-muted-foreground border border-border/50"
            >
              {feature}
            </span>
          ))}
        </motion.div>
      </div>
    </div>
  );
}

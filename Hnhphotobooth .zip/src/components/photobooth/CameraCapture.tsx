import { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Camera, X, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { usePhotobooth } from '@/contexts/PhotoboothContext';
import { useToast } from '@/components/ui/use-toast';

export function CameraCapture() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const capturedPhotosRef = useRef<number>(0);
  
  const { 
    shotCount, 
    capturedPhotos, 
    countdown,
    setCountdown,
    addCapturedPhoto,
    setStep,
    clearPhotos 
  } = usePhotobooth();
  
  const { toast } = useToast();
  const [isReady, setIsReady] = useState(false);
  const [showFlash, setShowFlash] = useState(false);
  
  // Keep track of captured photos count in ref to avoid stale closure
  useEffect(() => {
    capturedPhotosRef.current = capturedPhotos.length;
  }, [capturedPhotos.length]);

  useEffect(() => {
    startCamera();
    return () => {
      stopCamera();
    };
  }, []);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { 
          facingMode: 'user',
          width: { ideal: 1920 },
          height: { ideal: 1080 }
        },
        audio: false,
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        streamRef.current = stream;
        setIsReady(true);
      }
    } catch (error) {
      console.error('Camera access error:', error);
      toast({
        title: 'Camera Access Denied',
        description: 'Please enable camera access to use the photobooth.',
        variant: 'destructive',
      });
      setStep('welcome');
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
  };

  const capturePhoto = () => {
    if (!videoRef.current || !canvasRef.current) return;

    const video = videoRef.current;
    const canvas = canvasRef.current;
    const context = canvas.getContext('2d');

    if (!context) return;

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    context.drawImage(video, 0, 0);

    const dataUrl = canvas.toDataURL('image/jpeg', 0.95);
    
    addCapturedPhoto({
      id: `photo-${Date.now()}`,
      dataUrl,
      timestamp: Date.now(),
    });

    // Flash effect
    setShowFlash(true);
    setTimeout(() => setShowFlash(false), 150);

    // Play shutter sound (using Web Audio API)
    try {
      const audioContext = new AudioContext();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      
      oscillator.frequency.value = 800;
      gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.1);
      
      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 0.1);
    } catch (e) {
      // Audio context may fail on some browsers
      console.log('Audio not available');
    }
  };

  const startCountdown = () => {
    setCountdown(3);
  };

  useEffect(() => {
    if (countdown === null) return;

    if (countdown > 0) {
      // Play beep sound
      try {
        const audioContext = new AudioContext();
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        oscillator.frequency.value = 600 + (countdown * 100);
        gainNode.gain.setValueAtTime(0.2, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.1);
        
        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + 0.1);
      } catch (e) {
        // Audio context may fail on some browsers
        console.log('Audio not available');
      }

      const timer = setTimeout(() => {
        setCountdown(countdown - 1);
      }, 1000);

      return () => clearTimeout(timer);
    } else {
      capturePhoto();
      setCountdown(null);
      
      // Check if all shots are captured using ref for accurate count
      if (capturedPhotosRef.current + 1 >= shotCount) {
        setTimeout(() => {
          stopCamera();
          setStep('preview');
        }, 500);
      }
    }
  }, [countdown, shotCount, setCountdown, setStep]);

  const handleCancel = () => {
    stopCamera();
    clearPhotos();
    setStep('welcome');
  };

  const handleBack = () => {
    stopCamera();
    clearPhotos();
    setStep('frame-select');
  };

  const currentShot = capturedPhotos.length + 1;

  return (
    <div className="min-h-screen bg-black relative overflow-hidden">
      {/* Video Feed */}
      <video
        ref={videoRef}
        autoPlay
        playsInline
        muted
        className="absolute inset-0 w-full h-full object-cover scale-x-[-1]"
      />
      
      {/* Hidden canvas for capture */}
      <canvas ref={canvasRef} className="hidden" />

      {/* Face Guide Overlay */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="w-48 h-64 sm:w-64 sm:h-80 md:w-80 md:h-96 border-4 border-white/30 rounded-3xl" />
      </div>

      {/* Vignette Effect */}
      <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(circle_at_center,transparent_40%,rgba(0,0,0,0.4)_100%)]" />

      {/* Flash Effect */}
      <AnimatePresence>
        {showFlash && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.9 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.15 }}
            className="absolute inset-0 bg-white pointer-events-none"
          />
        )}
      </AnimatePresence>

      {/* Countdown Overlay */}
      <AnimatePresence>
        {countdown !== null && countdown > 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 flex items-center justify-center bg-black/50 backdrop-blur-sm"
          >
            <motion.div
              key={countdown}
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: [0.8, 1.2, 1], opacity: 1 }}
              exit={{ scale: 1.2, opacity: 0 }}
              transition={{ duration: 0.8 }}
              className="relative"
            >
              <div className="font-mono-display text-[120px] sm:text-[180px] md:text-[250px] lg:text-[300px] font-bold text-white drop-shadow-2xl">
                {countdown}
              </div>
              <svg className="absolute inset-0 -m-4 sm:-m-6 md:-m-8" viewBox="0 0 100 100">
                <motion.circle
                  cx="50"
                  cy="50"
                  r="45"
                  fill="none"
                  stroke="white"
                  strokeWidth="2"
                  strokeDasharray="283"
                  initial={{ strokeDashoffset: 283 }}
                  animate={{ strokeDashoffset: 0 }}
                  transition={{ duration: 1, ease: 'linear' }}
                />
              </svg>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Progress Bar */}
      <div className="absolute top-4 sm:top-6 md:top-8 left-0 right-0 flex justify-center gap-2 sm:gap-3 px-4 sm:px-8">
        {Array.from({ length: shotCount }, (_, i) => (
          <motion.div
            key={i}
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: i * 0.1 }}
            className={`w-8 h-8 sm:w-10 sm:h-10 md:w-12 md:h-12 rounded-full border-2 sm:border-4 overflow-hidden ${
              i < capturedPhotos.length
                ? 'bg-primary border-primary'
                : 'bg-white/20 border-white/40'
            }`}
          >
            {i < capturedPhotos.length && (
              <img
                src={capturedPhotos[i].dataUrl}
                alt={`Shot ${i + 1}`}
                className="w-full h-full rounded-full object-cover scale-x-[-1]"
              />
            )}
          </motion.div>
        ))}
      </div>

      {/* Shot Counter */}
      <div className="absolute top-16 sm:top-20 md:top-24 left-0 right-0 text-center">
        <p className="text-white text-lg sm:text-xl md:text-2xl font-display font-bold drop-shadow-lg">
          Shot {currentShot} of {shotCount}
        </p>
      </div>

      {/* Controls */}
      <div className="absolute bottom-4 sm:bottom-6 md:bottom-8 left-0 right-0 flex justify-center items-center gap-3 sm:gap-4 md:gap-6 px-4 sm:px-8">
        {/* Back Button - only show when not capturing */}
        {countdown === null && capturedPhotos.length === 0 && (
          <Button
            variant="outline"
            size="lg"
            onClick={handleBack}
            className="rounded-full bg-white/10 backdrop-blur-md border-white/20 text-white hover:bg-white/20 px-3 sm:px-4 py-2 sm:py-3"
          >
            <ArrowLeft className="mr-1 sm:mr-2 h-4 w-4 sm:h-5 sm:w-5" />
            <span className="text-sm sm:text-base">Back</span>
          </Button>
        )}

        {isReady && countdown === null && (
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: 'spring', stiffness: 200 }}
          >
            <Button
              size="lg"
              onClick={startCountdown}
              className="w-16 h-16 sm:w-20 sm:h-20 md:w-24 md:h-24 rounded-full bg-primary hover:bg-primary/90 shadow-2xl"
            >
              <Camera className="w-7 h-7 sm:w-8 sm:h-8 md:w-10 md:h-10" />
            </Button>
          </motion.div>
        )}

        {/* Cancel Button */}
        <Button
          variant="outline"
          size="lg"
          onClick={handleCancel}
          className="rounded-full bg-white/10 backdrop-blur-md border-white/20 text-white hover:bg-white/20 px-3 sm:px-4 py-2 sm:py-3"
        >
          <X className="mr-1 sm:mr-2 h-4 w-4 sm:h-5 sm:w-5" />
          <span className="text-sm sm:text-base">Cancel</span>
        </Button>
      </div>
    </div>
  );
}

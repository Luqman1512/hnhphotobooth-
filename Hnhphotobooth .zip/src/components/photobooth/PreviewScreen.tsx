import { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { Download, RotateCcw, Share2, Palette, Home, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { usePhotobooth } from '@/contexts/PhotoboothContext';
import { useToast } from '@/components/ui/use-toast';

export function PreviewScreen() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { 
    capturedPhotos, 
    selectedFrame, 
    shotCount,
    clearPhotos,
    setStep,
    resetSession 
  } = usePhotobooth();
  
  const { toast } = useToast();
  const [composedImage, setComposedImage] = useState<string>('');
  const [idleTimer, setIdleTimer] = useState<number>(30);
  const [isComposing, setIsComposing] = useState(true);

  useEffect(() => {
    if (capturedPhotos.length > 0 && selectedFrame) {
      // Re-compose image whenever frame changes
      composeImage();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [capturedPhotos.length, selectedFrame?.id, shotCount]);

  useEffect(() => {
    // Idle timeout
    const interval = setInterval(() => {
      setIdleTimer(prev => {
        if (prev <= 1) {
          resetSession();
          return 30;
        }
        return prev - 1;
      });
    }, 1000);

    // Reset timer on interaction
    const resetTimer = () => setIdleTimer(30);
    window.addEventListener('click', resetTimer);
    window.addEventListener('touchstart', resetTimer);

    return () => {
      clearInterval(interval);
      window.removeEventListener('click', resetTimer);
      window.removeEventListener('touchstart', resetTimer);
    };
  }, [resetSession]);

  const composeImage = async () => {
    if (!canvasRef.current || !selectedFrame || capturedPhotos.length === 0) return;
    setIsComposing(true);
    setComposedImage(''); // Clear previous image while composing

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size (high resolution for download)
    canvas.width = 1200;
    canvas.height = 1560;

    // Clear canvas first
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Get current frame reference to avoid stale closure
    const currentFrameId = selectedFrame.id;
    const currentFrameLayout = selectedFrame.layout;

    // Frame-specific styling
    const frameStyles: Record<string, { 
      bg: string; 
      accent: string; 
      photoBg: string;
      gradient?: { colors: string[], direction: string };
      borderRadius: number;
      photoBorderRadius: number;
      borderWidth: number;
      decorations?: (ctx: CanvasRenderingContext2D, w: number, h: number) => void;
    }> = {
      'cute-pastels': { 
        bg: '#FFE4EC', 
        accent: '#FFB6C1', 
        photoBg: '#FFFFFF',
        gradient: { colors: ['#FFB6C1', '#E6E6FA', '#FFB6C1'], direction: 'diagonal' },
        borderRadius: 24,
        photoBorderRadius: 16,
        borderWidth: 4,
        decorations: (ctx, w, h) => {
          // Stars and circles
          ctx.fillStyle = '#FFD700';
          ctx.globalAlpha = 0.6;
          ctx.beginPath();
          ctx.arc(80, h - 80, 20, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#FF69B4';
          ctx.beginPath();
          ctx.arc(140, h - 60, 14, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#87CEEB';
          ctx.beginPath();
          ctx.arc(w - 100, h - 90, 16, 0, Math.PI * 2);
          ctx.fill();
          ctx.globalAlpha = 1;
        }
      },
      'kawaii-doodles': { 
        bg: '#FFF0F5', 
        accent: '#FF69B4', 
        photoBg: '#FFFFFF',
        borderRadius: 24,
        photoBorderRadius: 16,
        borderWidth: 4,
        decorations: (ctx, w, h) => {
          // Kawaii faces
          const drawKawaiiFace = (x: number, y: number, size: number, color: string) => {
            ctx.fillStyle = color;
            ctx.beginPath();
            ctx.arc(x, y, size, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = '#333';
            ctx.beginPath();
            ctx.arc(x - size * 0.3, y - size * 0.15, size * 0.15, 0, Math.PI * 2);
            ctx.arc(x + size * 0.3, y - size * 0.15, size * 0.15, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = '#333';
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.arc(x, y + size * 0.1, size * 0.25, 0, Math.PI);
            ctx.stroke();
          };
          drawKawaiiFace(70, h - 80, 30, '#FFB6C1');
          drawKawaiiFace(w - 70, h - 80, 30, '#87CEEB');
          // Hearts
          ctx.fillStyle = '#FF69B4';
          ctx.font = '24px sans-serif';
          ctx.fillText('♥', 160, h - 60);
          ctx.fillText('♥', w - 180, h - 60);
        }
      },
      'minimal-modern': { 
        bg: '#FAFAFA', 
        accent: '#222222', 
        photoBg: '#FFFFFF',
        borderRadius: 8,
        photoBorderRadius: 4,
        borderWidth: 4,
        decorations: (ctx, w, h) => {
          ctx.strokeStyle = '#222';
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.moveTo(60, h - 100);
          ctx.lineTo(w - 60, h - 100);
          ctx.stroke();
        }
      },
      'elegant-wedding': { 
        bg: '#FFFEF5', 
        accent: '#D4AF37', 
        photoBg: '#FFFFFF',
        borderRadius: 16,
        photoBorderRadius: 8,
        borderWidth: 6,
        decorations: (ctx, w, h) => {
          // Gold floral corners
          ctx.strokeStyle = '#D4AF37';
          ctx.lineWidth = 3;
          // Top left
          ctx.beginPath();
          ctx.arc(40, 40, 20, 0, Math.PI * 2);
          ctx.stroke();
          // Top right
          ctx.beginPath();
          ctx.arc(w - 40, 40, 20, 0, Math.PI * 2);
          ctx.stroke();
          // Bottom decorative swirls
          ctx.beginPath();
          ctx.moveTo(100, h - 80);
          ctx.quadraticCurveTo(150, h - 100, 200, h - 80);
          ctx.quadraticCurveTo(250, h - 60, 300, h - 80);
          ctx.stroke();
          ctx.beginPath();
          ctx.moveTo(w - 100, h - 80);
          ctx.quadraticCurveTo(w - 150, h - 100, w - 200, h - 80);
          ctx.quadraticCurveTo(w - 250, h - 60, w - 300, h - 80);
          ctx.stroke();
        }
      },
      'fun-party': { 
        bg: '#FFFFFF', 
        accent: '#FF6B6B', 
        photoBg: '#FFFFFF',
        borderRadius: 24,
        photoBorderRadius: 16,
        borderWidth: 6,
        decorations: (ctx, w, h) => {
          // Confetti
          const colors = ['#FF6B6B', '#4ECDC4', '#FFE66D', '#FF6B6B'];
          for (let i = 0; i < 20; i++) {
            ctx.fillStyle = colors[i % colors.length];
            const x = 50 + Math.random() * (w - 100);
            const y = h - 150 + Math.random() * 100;
            ctx.save();
            ctx.translate(x, y);
            ctx.rotate(Math.random() * Math.PI);
            ctx.fillRect(-6, -6, 12, 12);
            ctx.restore();
          }
          // Circles
          ctx.fillStyle = '#FF6B6B';
          ctx.beginPath();
          ctx.arc(60, 60, 15, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#4ECDC4';
          ctx.beginPath();
          ctx.arc(120, 40, 10, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#FFE66D';
          ctx.beginPath();
          ctx.arc(w - 80, 70, 12, 0, Math.PI * 2);
          ctx.fill();
        }
      },
      'retro-film': { 
        bg: '#1a1a1a', 
        accent: '#f5f0e6', 
        photoBg: '#f5f0e6',
        borderRadius: 8,
        photoBorderRadius: 4,
        borderWidth: 0,
        decorations: (ctx, w, h) => {
          // Film perforations
          ctx.fillStyle = '#1a1a1a';
          for (let i = 0; i < 20; i++) {
            const y = 60 + i * 70;
            if (y < h - 100) {
              // Left perforations
              ctx.fillRect(20, y, 30, 20);
              // Right perforations
              ctx.fillRect(w - 50, y, 30, 20);
            }
          }
        }
      },
      'neon-night': { 
        bg: '#0a0a1a', 
        accent: '#00D9FF', 
        photoBg: '#111111',
        borderRadius: 24,
        photoBorderRadius: 16,
        borderWidth: 4,
        decorations: (ctx, w, h) => {
          // Neon glow lines
          ctx.shadowColor = '#00D9FF';
          ctx.shadowBlur = 20;
          ctx.strokeStyle = '#00D9FF';
          ctx.lineWidth = 4;
          ctx.beginPath();
          ctx.moveTo(60, h - 100);
          ctx.lineTo(200, h - 100);
          ctx.stroke();
          ctx.shadowColor = '#FF00FF';
          ctx.strokeStyle = '#FF00FF';
          ctx.beginPath();
          ctx.moveTo(w - 60, h - 100);
          ctx.lineTo(w - 200, h - 100);
          ctx.stroke();
          ctx.shadowBlur = 0;
        }
      },
      'floral-soft': { 
        bg: '#F5F0E8', 
        accent: '#8FBC8F', 
        photoBg: '#FFFFFF',
        borderRadius: 24,
        photoBorderRadius: 16,
        borderWidth: 4,
        decorations: (ctx, w, h) => {
          // Floral elements
          ctx.strokeStyle = '#8FBC8F';
          ctx.lineWidth = 3;
          // Left vine
          ctx.beginPath();
          ctx.moveTo(60, h - 60);
          ctx.quadraticCurveTo(100, h - 100, 140, h - 60);
          ctx.quadraticCurveTo(180, h - 20, 220, h - 60);
          ctx.stroke();
          // Right vine
          ctx.beginPath();
          ctx.moveTo(w - 60, h - 60);
          ctx.quadraticCurveTo(w - 100, h - 100, w - 140, h - 60);
          ctx.quadraticCurveTo(w - 180, h - 20, w - 220, h - 60);
          ctx.stroke();
          // Flowers
          ctx.fillStyle = '#DDA0DD';
          ctx.globalAlpha = 0.7;
          ctx.beginPath();
          ctx.arc(80, h - 80, 10, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#FFB6C1';
          ctx.beginPath();
          ctx.arc(130, h - 50, 8, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#DDA0DD';
          ctx.beginPath();
          ctx.arc(w - 80, h - 80, 10, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#FFB6C1';
          ctx.beginPath();
          ctx.arc(w - 130, h - 50, 8, 0, Math.PI * 2);
          ctx.fill();
          ctx.globalAlpha = 1;
        }
      },
    };

    const style = frameStyles[currentFrameId] || frameStyles['cute-pastels'];
    
    // Draw background
    if (style.gradient) {
      const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
      style.gradient.colors.forEach((color, i) => {
        gradient.addColorStop(i / (style.gradient!.colors.length - 1), color);
      });
      ctx.fillStyle = gradient;
    } else {
      ctx.fillStyle = style.bg;
    }
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Get layout from current frame
    const layout = currentFrameLayout(shotCount);

    // Load all images first
    const loadImage = (src: string): Promise<HTMLImageElement> => {
      return new Promise((resolve, reject) => {
        const img = new Image();
        img.onload = () => resolve(img);
        img.onerror = reject;
        img.src = src;
      });
    };

    try {
      const images = await Promise.all(capturedPhotos.map(photo => loadImage(photo.dataUrl)));
      
      images.forEach((img, index) => {
        if (index >= layout.slots.length) return;

        const slot = layout.slots[index];
        const x = (slot.x / 100) * canvas.width;
        const y = (slot.y / 100) * canvas.height;
        const width = (slot.width / 100) * canvas.width;
        const height = (slot.height / 100) * canvas.height;

        ctx.save();
        
        // Apply rotation if specified
        if (slot.rotation) {
          ctx.translate(x + width / 2, y + height / 2);
          ctx.rotate((slot.rotation * Math.PI) / 180);
          ctx.translate(-(x + width / 2), -(y + height / 2));
        }

        // Draw photo background
        const radius = style.photoBorderRadius;
        ctx.fillStyle = style.photoBg;
        ctx.beginPath();
        ctx.moveTo(x + radius, y);
        ctx.lineTo(x + width - radius, y);
        ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
        ctx.lineTo(x + width, y + height - radius);
        ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
        ctx.lineTo(x + radius, y + height);
        ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
        ctx.lineTo(x, y + radius);
        ctx.quadraticCurveTo(x, y, x + radius, y);
        ctx.closePath();
        ctx.fill();

        // Clip for photo
        ctx.beginPath();
        ctx.moveTo(x + radius, y);
        ctx.lineTo(x + width - radius, y);
        ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
        ctx.lineTo(x + width, y + height - radius);
        ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
        ctx.lineTo(x + radius, y + height);
        ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
        ctx.lineTo(x, y + radius);
        ctx.quadraticCurveTo(x, y, x + radius, y);
        ctx.closePath();
        ctx.clip();

        // Mirror the image horizontally (selfie mode)
        ctx.translate(x + width, y);
        ctx.scale(-1, 1);
        ctx.drawImage(img, 0, 0, width, height);
        ctx.restore();

        // Border
        if (style.borderWidth > 0) {
          ctx.strokeStyle = style.accent;
          ctx.lineWidth = style.borderWidth;
          ctx.beginPath();
          ctx.moveTo(x + radius, y);
          ctx.lineTo(x + width - radius, y);
          ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
          ctx.lineTo(x + width, y + height - radius);
          ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
          ctx.lineTo(x + radius, y + height);
          ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
          ctx.lineTo(x, y + radius);
          ctx.quadraticCurveTo(x, y, x + radius, y);
          ctx.closePath();
          ctx.stroke();
        }
      });

      // Draw frame decorations
      if (style.decorations) {
        style.decorations(ctx, canvas.width, canvas.height);
      }

      // Add branding
      const isDark = ['retro-film', 'neon-night', 'dark-luxury'].includes(currentFrameId);
      ctx.fillStyle = isDark ? 'rgba(255, 255, 255, 0.8)' : 'rgba(0, 0, 0, 0.5)';
      ctx.font = 'bold 28px Outfit, sans-serif';
      ctx.textAlign = 'right';
      ctx.fillText('HNH PHOTOBOOTH', canvas.width - 50, canvas.height - 50);

      // Add date
      ctx.font = '20px Outfit, sans-serif';
      ctx.fillText(new Date().toLocaleDateString(), canvas.width - 50, canvas.height - 20);

      setComposedImage(canvas.toDataURL('image/jpeg', 0.95));
      setIsComposing(false);
    } catch (error) {
      console.error('Error composing image:', error);
      setIsComposing(false);
    }
  };

  const handleDownload = () => {
    if (!composedImage) return;

    const link = document.createElement('a');
    link.download = `hnh-photobooth-${Date.now()}.jpg`;
    link.href = composedImage;
    link.click();

    toast({
      title: 'Photo Downloaded!',
      description: 'Your photobooth image has been saved.',
    });
  };

  const handleRetake = () => {
    clearPhotos();
    setStep('camera');
  };

  const handleChangeFrame = () => {
    setStep('frame-select');
  };

  const handleShare = async () => {
    if (!composedImage) return;

    try {
      const blob = await (await fetch(composedImage)).blob();
      const file = new File([blob], 'photobooth.jpg', { type: 'image/jpeg' });

      if (navigator.share) {
        await navigator.share({
          files: [file],
          title: 'HNH Photobooth',
          text: 'Check out my photobooth picture!',
        });
      } else {
        // Fallback: just download
        handleDownload();
      }
    } catch (error) {
      console.error('Share error:', error);
      toast({
        title: 'Share Not Available',
        description: 'Download the image instead.',
        variant: 'destructive',
      });
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center noise-texture p-4 sm:p-6 md:p-8">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-lg md:max-w-xl lg:max-w-2xl w-full"
      >
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-4 sm:mb-6 md:mb-8"
        >
          <div className="flex items-center justify-center gap-2 mb-2">
            <Sparkles className="w-6 h-6 sm:w-8 sm:h-8 text-primary" />
            <h2 className="font-display font-bold text-3xl sm:text-4xl md:text-5xl">
              Your Photos!
            </h2>
            <Sparkles className="w-6 h-6 sm:w-8 sm:h-8 text-primary" />
          </div>
          <p className="text-muted-foreground text-sm sm:text-base">
            Frame: {selectedFrame?.name}
          </p>
        </motion.div>

        {/* Preview */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="relative mb-4 sm:mb-6 md:mb-8 rounded-2xl sm:rounded-3xl overflow-hidden shadow-2xl bg-card"
        >
          {composedImage && !isComposing ? (
            <img
              src={composedImage}
              alt="Composed photobooth"
              className="w-full h-auto"
            />
          ) : (
            <div className="aspect-[3/4] flex flex-col items-center justify-center gap-4">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full"
              />
              <p className="text-muted-foreground">Composing your photos...</p>
            </div>
          )}
        </motion.div>

        {/* Hidden canvas for composition */}
        <canvas ref={canvasRef} className="hidden" />

        {/* Action Buttons */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="grid grid-cols-2 gap-2 sm:gap-3 md:gap-4 mb-4 sm:mb-6 md:mb-8"
        >
          <Button
            variant="outline"
            size="lg"
            onClick={handleRetake}
            className="flex-col h-auto py-4 sm:py-5 md:py-6 rounded-xl sm:rounded-2xl"
          >
            <RotateCcw className="w-5 h-5 sm:w-6 sm:h-6 md:w-8 md:h-8 mb-1 sm:mb-2" />
            <span className="text-xs sm:text-sm">Retake All</span>
          </Button>

          <Button
            variant="outline"
            size="lg"
            onClick={handleChangeFrame}
            className="flex-col h-auto py-4 sm:py-5 md:py-6 rounded-xl sm:rounded-2xl"
          >
            <Palette className="w-5 h-5 sm:w-6 sm:h-6 md:w-8 md:h-8 mb-1 sm:mb-2" />
            <span className="text-xs sm:text-sm">Change Frame</span>
          </Button>

          <Button
            size="lg"
            onClick={handleDownload}
            className="flex-col h-auto py-4 sm:py-5 md:py-6 rounded-xl sm:rounded-2xl"
          >
            <Download className="w-5 h-5 sm:w-6 sm:h-6 md:w-8 md:h-8 mb-1 sm:mb-2" />
            <span className="text-xs sm:text-sm">Download</span>
          </Button>

          <Button
            size="lg"
            onClick={handleShare}
            className="flex-col h-auto py-4 sm:py-5 md:py-6 rounded-xl sm:rounded-2xl"
          >
            <Share2 className="w-5 h-5 sm:w-6 sm:h-6 md:w-8 md:h-8 mb-1 sm:mb-2" />
            <span className="text-xs sm:text-sm">Share</span>
          </Button>
        </motion.div>

        {/* Home Button */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="flex justify-center mb-4"
        >
          <Button
            variant="ghost"
            onClick={resetSession}
            className="text-muted-foreground hover:text-foreground"
          >
            <Home className="w-4 h-4 mr-2" />
            Start New Session
          </Button>
        </motion.div>

        {/* Idle Timer Warning */}
        {idleTimer <= 10 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center p-3 bg-destructive/10 rounded-xl"
          >
            <p className="text-destructive text-sm sm:text-base font-medium">
              Resetting in {idleTimer} seconds...
            </p>
          </motion.div>
        )}
      </motion.div>
    </div>
  );
}

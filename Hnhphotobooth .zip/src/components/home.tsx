import { PhotoboothProvider } from '@/contexts/PhotoboothContext';
import { Photobooth } from './photobooth/Photobooth';
import { Toaster } from './ui/toaster';
import { useDarkMode } from '@/hooks/useDarkMode';

function Home() {
  // Initialize dark mode based on system preference
  useDarkMode();

  return (
    <PhotoboothProvider>
      <div className="w-screen h-screen">
        <Photobooth />
        <Toaster />
      </div>
    </PhotoboothProvider>
  );
}

export default Home

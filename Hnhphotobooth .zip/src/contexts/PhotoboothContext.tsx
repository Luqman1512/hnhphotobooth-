import React, { createContext, useContext, useState, useCallback } from 'react';
import { PhotoboothState, PhotoboothStep, FrameDesign, CapturedPhoto } from '@/types/photobooth';

interface PhotoboothContextType extends PhotoboothState {
  setStep: (step: PhotoboothStep) => void;
  setShotCount: (count: number) => void;
  setSelectedFrame: (frame: FrameDesign) => void;
  addCapturedPhoto: (photo: CapturedPhoto) => void;
  clearPhotos: () => void;
  setIsCapturing: (capturing: boolean) => void;
  setCountdown: (countdown: number | null) => void;
  resetSession: () => void;
}

const PhotoboothContext = createContext<PhotoboothContextType | undefined>(undefined);

const initialState: PhotoboothState = {
  step: 'welcome',
  shotCount: 4,
  selectedFrame: null,
  capturedPhotos: [],
  isCapturing: false,
  countdown: null,
};

export function PhotoboothProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<PhotoboothState>(initialState);

  const setStep = useCallback((step: PhotoboothStep) => {
    setState(prev => ({ ...prev, step }));
  }, []);

  const setShotCount = useCallback((count: number) => {
    setState(prev => ({ ...prev, shotCount: count }));
  }, []);

  const setSelectedFrame = useCallback((frame: FrameDesign) => {
    setState(prev => ({ ...prev, selectedFrame: frame }));
  }, []);

  const addCapturedPhoto = useCallback((photo: CapturedPhoto) => {
    setState(prev => ({ 
      ...prev, 
      capturedPhotos: [...prev.capturedPhotos, photo] 
    }));
  }, []);

  const clearPhotos = useCallback(() => {
    setState(prev => ({ ...prev, capturedPhotos: [] }));
  }, []);

  const setIsCapturing = useCallback((capturing: boolean) => {
    setState(prev => ({ ...prev, isCapturing: capturing }));
  }, []);

  const setCountdown = useCallback((countdown: number | null) => {
    setState(prev => ({ ...prev, countdown }));
  }, []);

  const resetSession = useCallback(() => {
    setState(initialState);
  }, []);

  return (
    <PhotoboothContext.Provider
      value={{
        ...state,
        setStep,
        setShotCount,
        setSelectedFrame,
        addCapturedPhoto,
        clearPhotos,
        setIsCapturing,
        setCountdown,
        resetSession,
      }}
    >
      {children}
    </PhotoboothContext.Provider>
  );
}

export function usePhotobooth() {
  const context = useContext(PhotoboothContext);
  if (!context) {
    throw new Error('usePhotobooth must be used within PhotoboothProvider');
  }
  return context;
}

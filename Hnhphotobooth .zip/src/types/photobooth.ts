export type PhotoboothStep = 
  | 'welcome'
  | 'shot-select'
  | 'frame-select'
  | 'camera'
  | 'preview';

export interface CapturedPhoto {
  id: string;
  dataUrl: string;
  timestamp: number;
}

export interface FrameDesign {
  id: string;
  name: string;
  thumbnail: string;
  category: 'cute' | 'elegant' | 'fun' | 'minimal' | 'retro' | 'modern';
  layout: (count: number) => PhotoLayout;
}

export interface PhotoLayout {
  slots: PhotoSlot[];
  frameStyle: React.CSSProperties;
}

export interface PhotoSlot {
  x: number;
  y: number;
  width: number;
  height: number;
  rotation?: number;
}

export interface PhotoboothState {
  step: PhotoboothStep;
  shotCount: number;
  selectedFrame: FrameDesign | null;
  capturedPhotos: CapturedPhoto[];
  isCapturing: boolean;
  countdown: number | null;
}
